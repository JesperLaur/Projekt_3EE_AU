/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>
#include <stdint.h>

char buf[128];
uint16 adcResult;
float adcInVolts;

void ChargingStatus()
{
    for(;;)
    {
        ADC_SAR_StartConvert();
        if (ADC_SAR_IsEndConversion(ADC_SAR_RETURN_STATUS) != 0)
        {
            
            adcResult = ADC_SAR_GetResult16();
            adcInVolts = ADC_SAR_CountsTo_mVolts(adcResult);
            sniprintf(buf, sizeof(buf), "V_C = %f mV\r\n", adcInVolts);
            UART_PutString(buf);
            
        }
    CyDelay(1000);
    ADC_SAR_StopConvert();
    }
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    ADC_SAR_Start();
    UART_Start();
    ChargingStatus();
    
    UART_PutString("klar\r\n");
    
    for(;;)
    {
    }
}

/* [] END OF FILE */
