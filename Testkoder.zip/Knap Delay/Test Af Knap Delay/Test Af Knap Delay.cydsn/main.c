/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>

char buf[128];
static int i;


CY_ISR(KnapDelay)
{
    for(;;)
    {
        if ((CyPins_ReadPin(Knap_0) < 2))
        {
            i+=100;
            CyDelay(80);
        }
        else 
        {
            i=0;
        }
    }
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    UART_Start();
    
    
    
    
    for(;;)
    {
        isr_knap_StartEx(KnapDelay);
        snprintf(buf, sizeof(buf), "Knap holdt nede i %i ms\r\n", i);
        UART_PutString(buf);
        
    }
}

/* [] END OF FILE */
