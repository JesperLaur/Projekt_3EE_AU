/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

int main()
{
    
	CyGlobalIntEnable; /* Enable global interrupts. */
	
	I2C_CharLCD_Start();
	CharLCD_Start();
	
	for(;;)
    {
		CharLCD_Position(0u,0u);
		CharLCD_PrintString("CYPRESS PSoC5 LP");
		//CharLCD_Position(1u,2u);
		CharLCD_PosPrintString(3u,5u,"HELLO WORLD");
   		CyDelay(1u);
	}
}

/* [] END OF FILE */
