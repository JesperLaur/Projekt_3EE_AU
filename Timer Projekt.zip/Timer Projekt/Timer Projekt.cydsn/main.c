/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>
#define Tperiod 10000

//char buf3[128];
//char buf4[128];



CY_ISR(isr1)
{
  //  static volatile int time1;
//static volatile int time2;
static volatile float time;
static volatile float timeRead;

float frekvens = 10000.0;
    char buf[128];
    char buf2[128];

UART_PutString("ISR loop aktivt\r\n");
         PWM_1_Stop();
        //time1=Timer_ReadCapture();  //read measurement
        Timer_ReadStatusRegister();
        
        //time2=Timer_ReadCapture();  
        
        timeRead= 65535-Timer_ReadCapture();
        time=(1/frekvens)*timeRead;  //time calculation
        
        snprintf(buf, sizeof(buf), "tid: %f s\r\n", time);
        snprintf(buf2, sizeof(buf2), "timeRead: %f ms\r\n", timeRead);
        UART_PutString(buf2);
        UART_PutString(buf); 
        
        PWM_1_Start();
        
      
}


int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    UART_Start();
    Timer_Start();
    isr_StartEx(isr1);
    ClockTimer_Start();
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    for(;;)
    {
        /*int sensor1 = CyPins_ReadPin(sensor_1_0);
        int sensor2 = CyPins_ReadPin(Sensor_2_0);
        snprintf(buf3, sizeof(buf3), "Sensor_1 = %i\r\n", sensor1);
        snprintf(buf4, sizeof(buf4), "Sensor_2 = %i\r\n", sensor2);
        UART_PutString(buf3);
        UART_PutString(buf4);*/
        UART_PutString("Main kode\r\n");
        CyDelay(500);
        
    }
}

/* [] END OF FILE */
