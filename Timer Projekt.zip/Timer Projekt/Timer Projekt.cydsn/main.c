/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>
#define Tperiod 10000

static volatile int time;

char buf[128];
char buf2[128];


CY_ISR(isr1)
{
        Timer_ReadStatusRegister();   
        time=Timer_ReadCapture();
               
        sniprintf(buf, sizeof(buf), "tid: %d ms\r\n", time);
        UART_PutString(buf);    
      
}


int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    UART_Start();
    Timer_Start();
    isr_StartEx(isr1);
    ClockTimer_Start();
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    for(;;)
    {
        //isr();
    }
}

/* [] END OF FILE */
