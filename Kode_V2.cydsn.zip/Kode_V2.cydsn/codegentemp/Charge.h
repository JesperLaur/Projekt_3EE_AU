/*******************************************************************************
* File Name: Charge.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Charge_H) /* Pins Charge_H */
#define CY_PINS_Charge_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Charge_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Charge__PORT == 15 && ((Charge__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Charge_Write(uint8 value);
void    Charge_SetDriveMode(uint8 mode);
uint8   Charge_ReadDataReg(void);
uint8   Charge_Read(void);
void    Charge_SetInterruptMode(uint16 position, uint16 mode);
uint8   Charge_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Charge_SetDriveMode() function.
     *  @{
     */
        #define Charge_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Charge_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Charge_DM_RES_UP          PIN_DM_RES_UP
        #define Charge_DM_RES_DWN         PIN_DM_RES_DWN
        #define Charge_DM_OD_LO           PIN_DM_OD_LO
        #define Charge_DM_OD_HI           PIN_DM_OD_HI
        #define Charge_DM_STRONG          PIN_DM_STRONG
        #define Charge_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Charge_MASK               Charge__MASK
#define Charge_SHIFT              Charge__SHIFT
#define Charge_WIDTH              1u

/* Interrupt constants */
#if defined(Charge__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Charge_SetInterruptMode() function.
     *  @{
     */
        #define Charge_INTR_NONE      (uint16)(0x0000u)
        #define Charge_INTR_RISING    (uint16)(0x0001u)
        #define Charge_INTR_FALLING   (uint16)(0x0002u)
        #define Charge_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Charge_INTR_MASK      (0x01u) 
#endif /* (Charge__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Charge_PS                     (* (reg8 *) Charge__PS)
/* Data Register */
#define Charge_DR                     (* (reg8 *) Charge__DR)
/* Port Number */
#define Charge_PRT_NUM                (* (reg8 *) Charge__PRT) 
/* Connect to Analog Globals */                                                  
#define Charge_AG                     (* (reg8 *) Charge__AG)                       
/* Analog MUX bux enable */
#define Charge_AMUX                   (* (reg8 *) Charge__AMUX) 
/* Bidirectional Enable */                                                        
#define Charge_BIE                    (* (reg8 *) Charge__BIE)
/* Bit-mask for Aliased Register Access */
#define Charge_BIT_MASK               (* (reg8 *) Charge__BIT_MASK)
/* Bypass Enable */
#define Charge_BYP                    (* (reg8 *) Charge__BYP)
/* Port wide control signals */                                                   
#define Charge_CTL                    (* (reg8 *) Charge__CTL)
/* Drive Modes */
#define Charge_DM0                    (* (reg8 *) Charge__DM0) 
#define Charge_DM1                    (* (reg8 *) Charge__DM1)
#define Charge_DM2                    (* (reg8 *) Charge__DM2) 
/* Input Buffer Disable Override */
#define Charge_INP_DIS                (* (reg8 *) Charge__INP_DIS)
/* LCD Common or Segment Drive */
#define Charge_LCD_COM_SEG            (* (reg8 *) Charge__LCD_COM_SEG)
/* Enable Segment LCD */
#define Charge_LCD_EN                 (* (reg8 *) Charge__LCD_EN)
/* Slew Rate Control */
#define Charge_SLW                    (* (reg8 *) Charge__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Charge_PRTDSI__CAPS_SEL       (* (reg8 *) Charge__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Charge_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Charge__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Charge_PRTDSI__OE_SEL0        (* (reg8 *) Charge__PRTDSI__OE_SEL0) 
#define Charge_PRTDSI__OE_SEL1        (* (reg8 *) Charge__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Charge_PRTDSI__OUT_SEL0       (* (reg8 *) Charge__PRTDSI__OUT_SEL0) 
#define Charge_PRTDSI__OUT_SEL1       (* (reg8 *) Charge__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Charge_PRTDSI__SYNC_OUT       (* (reg8 *) Charge__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Charge__SIO_CFG)
    #define Charge_SIO_HYST_EN        (* (reg8 *) Charge__SIO_HYST_EN)
    #define Charge_SIO_REG_HIFREQ     (* (reg8 *) Charge__SIO_REG_HIFREQ)
    #define Charge_SIO_CFG            (* (reg8 *) Charge__SIO_CFG)
    #define Charge_SIO_DIFF           (* (reg8 *) Charge__SIO_DIFF)
#endif /* (Charge__SIO_CFG) */

/* Interrupt Registers */
#if defined(Charge__INTSTAT)
    #define Charge_INTSTAT            (* (reg8 *) Charge__INTSTAT)
    #define Charge_SNAP               (* (reg8 *) Charge__SNAP)
    
	#define Charge_0_INTTYPE_REG 		(* (reg8 *) Charge__0__INTTYPE)
#endif /* (Charge__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Charge_H */


/* [] END OF FILE */
